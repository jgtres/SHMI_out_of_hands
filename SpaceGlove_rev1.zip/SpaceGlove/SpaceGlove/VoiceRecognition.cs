﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SpaceGlove
{
    class VoiceRecognition
    {
        PXCMAudioSource source;
        PXCMSpeechRecognition sr;

        private IReportVoiceRecognitionData _reportVoiceData;

        //private AutoResetEvent _autoReset = new AutoResetEvent(false);

        //public AutoResetEvent AutoReset
        //{
        //    get
        //    {
        //        return _autoReset;
        //    }
        //}
        public bool Stop;

        private IReportVoiceRecognitionData reportVoiceData
        {
            get
            {
                if (_reportVoiceData == null)
                {
                    _reportVoiceData = new ReportNoVoiceData();
                }
                return _reportVoiceData;
            }
            set
            {
                _reportVoiceData = value;
            }
        }

        public VoiceRecognition()
        {
            
        }

        public VoiceRecognition(IReportVoiceRecognitionData reportData) : this()
        {
            reportVoiceData = reportData;
        }

        void OnRecognition(PXCMSpeechRecognition.RecognitionData data)
        {
            if (data.scores[0].label < 0)
            {
                RecognitionData reportData = new RecognitionData() {Sentence = data.scores[0].sentence, Tag = data.scores[0].tags, Coinfidence = data.scores[0].confidence};
                reportVoiceData.ReportVoiceData(reportData);
            }
        }

        void OnAlert(PXCMSpeechRecognition.AlertData data)
        {
            
        }

        void CleanUp()
        {
            if (sr != null)
            {
                sr.Dispose();
                sr = null;
            }
            if (source != null)
            {
                source.Dispose();
                source = null;
            }
        }

        private PXCMAudioSource.DeviceInfo GetDeviceInfo(PXCMSession session)
        {
            PXCMAudioSource.DeviceInfo device = null;
            PXCMAudioSource source = session.CreateAudioSource();
            source.ScanDevices();
            for (int i = 0; ; i++)
            {
               PXCMAudioSource.DeviceInfo dinfo;
               if (source.QueryDeviceInfo(i, out dinfo) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
               if (dinfo.name.Contains("Creative"))
               {
                   device = dinfo;
                   break;
               }
            }
            source.Dispose();  
            return device;
        }

        private PXCMSession.ImplDesc GetModule(PXCMSession session)
        {
            PXCMSession.ImplDesc module = null;
            var desc = new PXCMSession.ImplDesc();
            desc.cuids[0] = PXCMSpeechRecognition.CUID;
            for (int i = 0; ; i++)
            {
                PXCMSession.ImplDesc desc1;
                if (session.QueryImpl(desc, i, out desc1) < pxcmStatus.PXCM_STATUS_NO_ERROR) break;
                if (desc1.friendlyName.Contains("Voice"))
                {
                    module = desc1;
                    break;
                }
            }
            return module;
        }

        public void DoIt(PXCMSession session)
        {

            /* Create the AudioSource instance */
            source=session.CreateAudioSource();

            if (source == null) {
                CleanUp();
                return;
            }

            /* Set audio volume to 0.2 */
            source.SetVolume(0.2f);

        	/* Set Audio Source */
            source.SetDevice(GetDeviceInfo(session));

            /* Set Module */
            PXCMSession.ImplDesc mdesc = new PXCMSession.ImplDesc();
            mdesc.iuid = GetModule(session).iuid;

            session.CreateImpl<PXCMSpeechRecognition>(out sr);
            PXCMSpeechRecognition.ProfileInfo pinfo;
            sr.QueryProfile(0, out pinfo);
            sr.SetProfile(pinfo);
            sr.SetDictation();
            var handler = new PXCMSpeechRecognition.Handler {onRecognition = OnRecognition, onAlert = OnAlert};
            sr.StartRec(source, handler);
            while (!Stop)
            {
                Thread.Sleep(5);
            }
            //AutoReset.WaitOne();
            CleanUp();
        }
    }

}
