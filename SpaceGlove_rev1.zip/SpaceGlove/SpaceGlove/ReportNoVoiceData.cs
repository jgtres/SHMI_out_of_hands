﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceGlove
{
    class ReportNoVoiceData : IReportVoiceRecognitionData
    {
        public void ReportVoiceData(RecognitionData data)
        {

        }
    }
}
