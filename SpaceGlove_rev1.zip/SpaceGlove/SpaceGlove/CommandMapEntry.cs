﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceGlove
{
    public class CommandMapEntry
    {
        public string Voice { get; set; }
        public string HardwareCommand { get; set; }
    }
}
