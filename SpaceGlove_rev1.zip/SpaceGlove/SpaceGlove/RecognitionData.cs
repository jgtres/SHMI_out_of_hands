﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceGlove
{
    public class RecognitionData
    {
        public string Sentence { get; set; }
        public string Tag { get; set; }
        public int Coinfidence { get; set; }
    }
}
