﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SpaceGlove.Properties;

namespace SpaceGlove
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, IReportVoiceRecognitionData
    {
        private SerialPort _serialPort = new SerialPort();
        private SerialPort _serialPort1 = new SerialPort();

        System.Windows.Threading.DispatcherTimer dispatcherTimer = new System.Windows.Threading.DispatcherTimer();

        private int _counterForDot;
        private int _counterForDot1;

        private List<string> _inputHistory;
        private List<string> _inputHistory1;

        // voice recognition
        private Thread _voiceRecognitionThread;

        private PXCMSession _vsession;

        private VoiceRecognition _voiceRecognition;

        // voice recognition

        //commands
        private List<CommandMapEntry> _commandMap = new List<CommandMapEntry>()
        {
            new CommandMapEntry() {Voice = "Right", HardwareCommand ="R"},
            new CommandMapEntry() {Voice = "Left", HardwareCommand ="L"},
            new CommandMapEntry() {Voice = "Up", HardwareCommand ="U"},
            new CommandMapEntry() {Voice = "Down", HardwareCommand ="D"},
            new CommandMapEntry() {Voice = "Stop", HardwareCommand ="S"},
        }; 
        //commands

        public MainWindow()
        {
            InitializeComponent();
            _serialPort.ReadTimeout = 500;
            _serialPort.WriteTimeout = 500;
            _serialPort.PortName = Settings.Default.ComNameForWritting;
            _serialPort1.ReadTimeout = 500;
            _serialPort1.WriteTimeout = 500;
            _serialPort1.PortName = Settings.Default.ComNameForReading;
            _serialPort1.DataReceived += DataReceivedHandler;
            _inputHistory = new List<string>();
            _inputHistory1 = new List<string>();
            dispatcherTimer.Tick += dispatcherTimer_Tick;
            dispatcherTimer.Interval = new TimeSpan(0, 0, 1);
            dispatcherTimer.Start();
            try
            {
                _serialPort.Open();
                _serialPort1.Open();

            }
            catch (Exception ex)
            {
                MessageBox.Show(this, ex.Message, "Error opening serial ports; shutting down...", MessageBoxButton.OK,
                    MessageBoxImage.Error);
                this.Close();
                return;
            }
            _vsession = PXCMSession.CreateInstance();
            _voiceRecognitionThread = new Thread(DoVoiceRecognition);
            _voiceRecognitionThread.Start();
        }

        public void DotNewCoordinates(int x, int y)
        {
            Canvas.SetLeft(Dot,x);
            Canvas.SetTop(Dot,y);
        }

        public void Dot1NewCoordinates(int x, int y)
        {
            Canvas.SetLeft(Dot1, x);
            Canvas.SetTop(Dot1, y);
        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            _counterForDot += 1;
            _counterForDot1 += 2;
            DotNewCoordinates(_counterForDot % 100,_counterForDot %100);
            Dot1NewCoordinates(_counterForDot1 % 100, _counterForDot1 % 100);
      


            // code goes here
        }

        private void SendMessageInOneLineToSerial(string message)
        {
            try
            {
                _serialPort.WriteLine(message);
            }
            catch
            {
            }            
        }


        private void DataReceivedHandler(
                            object sender,
                            SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort)sender;
            string indata = sp.ReadExisting();
            Dispatcher.InvokeAsync(() =>
            {
                _inputHistory1.Add(indata); 
                if (_inputHistory1.Count > 10) _inputHistory1.RemoveAt(0);
                InputLogList1.ItemsSource = null;
                InputLogList1.ItemsSource = _inputHistory1;
            });
          }
        
        private void SetupSpeachRecognition()
        {
            
        }


        private void DoVoiceRecognition()
        {
            
            _voiceRecognition = new VoiceRecognition(this);
            _voiceRecognition.DoIt(_vsession);


        }

        public void ReportVoiceData(RecognitionData data)
        {
            Dispatcher.InvokeAsync(() =>
            {
                _inputHistory.Add(data.Sentence + "**" + data.Coinfidence + "**" + data.Tag);
                if (_inputHistory.Count > 10) _inputHistory.RemoveAt(0);
                InputLogList.ItemsSource = null;
                InputLogList.ItemsSource = _inputHistory;
                var voice = data.Sentence.Trim();
                if (_commandMap.Any(x => x.Voice == voice))
                {
                    var message = _commandMap.Find(x => x.Voice == voice).HardwareCommand;
                    SendMessageInOneLineToSerial(message);
                    LVoiceCommand.Content = voice;
                    LHardwareCommand.Content = message;
                }
                
            });
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            if (_voiceRecognition== null) return;
            _voiceRecognition.Stop=true;
            _serialPort1.Close();
            _serialPort.Close();
        }
    }

}
